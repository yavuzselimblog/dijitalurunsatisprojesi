<?php

namespace Iyzipay\Model;

class Status
{
    const SUCCESS = "success";
    const FAILURE = "failure";
}