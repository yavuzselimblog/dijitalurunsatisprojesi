<?php

namespace Iyzipay\Model;

class SubMerchantType
{
    const PERSONAL = "PERSONAL";
    const PRIVATE_COMPANY = "PRIVATE_COMPANY";
    const LIMITED_OR_JOINT_STOCK_COMPANY = "LIMITED_OR_JOINT_STOCK_COMPANY";
}