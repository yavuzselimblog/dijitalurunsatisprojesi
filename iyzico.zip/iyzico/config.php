<?php

require_once('IyzipayBootstrap.php');

IyzipayBootstrap::init();

class Config
{
    public static function options()
    {
        $options = new \Iyzipay\Options();
        $options->setApiKey("9Wo0iDLDuTp7BsHxodyy5COTKZl6RLdb");
        $options->setSecretKey("544O47GZiyW8IUvdebE0pJ3KQ07hoacY");
        $options->setBaseUrl("https://api.iyzipay.com/");
        return $options;
    }
}